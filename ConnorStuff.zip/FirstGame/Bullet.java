import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bullet extends Actor
{
    boolean right;
    /**
     * Act - do whatever the bullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Bullet(boolean rightFacing)
    {
        GreenfootImage bulletImg = new GreenfootImage("bullet.png");
        bulletImg.scale(bulletImg.getWidth()/20,bulletImg.getHeight()/20);
        setImage(bulletImg);
        right = rightFacing;
    }
    public void act() 
    {
        if(right)
        {
            setLocation(getX()+5,getY());
        }
        else
        {
            setLocation(getX()-5,getY());
        }
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        }
    }    
}
