import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class submitSide here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class submitSide extends Actor
{
    /**
     * Act - do whatever the submitSide wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GreenfootImage[] laserCycle = new GreenfootImage[6];
    int animCounter = 0;
    int animCounter2 = 18;
    int stage = 0;
    int fireTimer = 0;
    boolean fromRight;
    int moveCount = 0;
    int fireStage = 0;
    int count = 0;
    int random1 = (int)(Math.random()*500);
    int random2 = (int)(Math.random()*500) + 500;
    int random3 = (int)(Math.random()*500) + 1000;
    boolean second = true;
    boolean third = true;
    public submitSide(boolean isFromRight)
    {
        for(int i = 1; i<7; i++)
        {
            laserCycle[i-1] = new GreenfootImage("submit" + i + ".png");
            if(isFromRight)
            {
                laserCycle[i-1].rotate(180);
            }
            laserCycle[i-1].scale(laserCycle[i-1].getWidth()/2,laserCycle[i-1].getHeight()/2);
        }
        this.setImage(laserCycle[0]);
        fromRight = isFromRight;
        
    }
    
    public void act() 
    {
        if(fromRight)
        {
            right();
        }
        else
        {
            left();
        }
        count++;
        if(count >= random1 && count<=random1+80)
        {
            fire();
        }
        if(count >= random2 && count<=random2+80)
        {
            if(second)
            {
                fireStage = 0;
                second = false;
            }
            fire();
        }
        if(count >= random3 && count<=random3+80)
        {
            if(third)
            {
                fireStage = 0;
                third = false;
            }
            fire();
            
        }
        if(count>1500)
        {
            stage = 2;
        }
        
    }
    public void fire()
    {
        if(animCounter<18 && fireStage == 0)
        {
            setImage(laserCycle[animCounter/3]);
            animCounter++;
        }
        else if(fireStage == 0)
        {
            fireStage = 1;
            laserSide beam = new laserSide(fromRight);
            getWorld().addObject(beam,getX(),getY());
        }
        if(fireStage == 1 && fireTimer < 25)
        {
            fireTimer += 1;
        }
        else if(fireStage == 1)
        {
            fireStage = 2;
        }
        if(fireStage == 2 && animCounter2>=0 )
        {
            
            animCounter2--;
            setImage(laserCycle[animCounter2/3]);
            
        }
        else if(fireStage == 2)
        {
            animCounter2 = 18;
            animCounter = 0;
            fireTimer = 0;
            fireStage = 3;
        }
    }
    public void right()
    {
        
        if(moveCount<50 && stage == 0)
        {
            setLocation(getX()-1,getY());
            moveCount++;
        }
        else if(stage == 0)
        {
            stage = 1;
        }
        
        if(!isAtEdge() && stage == 2)
        {
            setLocation(getX()+1,getY());
        }
        else if(isAtEdge() && stage == 2)
        {
            getWorld().removeObject(this);
        }
        
     
    }
    
    public void left()
    {
        
        if(moveCount<50 && stage == 0)
        {
            setLocation(getX()+1,getY());
            moveCount++;
        }
        else if(stage == 0)
        {
            stage = 1;
        }
        if(stage == 2 && animCounter2>=0 )
        {
            
            animCounter2--;
            setImage(laserCycle[animCounter2/3]);
            
        }
        else if(stage ==2)
        {
            stage = 3;
        }
        if(!isAtEdge() && stage == 3)
        {
            setLocation(getX()-1,getY());
        }
        else if(isAtEdge() && stage == 3)
        {
            getWorld().removeObject(this);
        }
        
     
    }
    
}
