import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HP here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HP extends Actor
{
    /**
     * Act - do whatever the HP wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int HpWidth = 140;
    int currentHP;
    boolean poop = true;
    public HP(int theCurrentHP)
    {
        GreenfootImage HpImg = new GreenfootImage("red.png");
        HpImg.scale(HpWidth,19);
        setImage(HpImg);
        currentHP = theCurrentHP;
        HpWidth = currentHP;
    }
    public void configure()
    {
        GreenfootImage HpImg = new GreenfootImage(getImage());
        HpImg.scale(HpWidth,getImage().getHeight());
        setImage(HpImg);
        setLocation(getX()-(140-HpWidth)/2,getY());
    }
    public void damage(int dm)
    {
        
        if(HpWidth-dm >= 1)
        {
            GreenfootImage HpImg = new GreenfootImage(getImage());
            HpImg.scale(HpWidth-dm,getImage().getHeight());
            setImage(HpImg);
            HpWidth = HpWidth-dm;
            currentHP -= dm;
            setLocation(getX()-dm/2,getY());
        }
        else
        {
            Greenfoot.setWorld(new GameOver());
            
            Greenfoot.stop();
        }
    }

    public void act() 
    {
        if(poop)
        {
            configure();
            poop = false;
        }

    }    
    public int getCurrentHP()
    {
        return currentHP;
    }
}
