import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelC here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelC extends World
{

    /**
     * Constructor for objects of class LevelC.
     * 
     */
    int CurrentHP;
    public LevelC(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(766, 829, 1);
        setBackground("LevelC.jpeg");
        if(entrance == 1)
        {
            Main main = new Main();
            addObject(main,700,700);

        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    public void prepare()
    {
        HP hP = new HP(CurrentHP);
        addObject(hP,495,542);
        HpBar hpBar = new HpBar();
        addObject(hpBar,446,259);
        hpBar.setLocation(91,32);
        hP.setLocation(101,31);

    }
}
