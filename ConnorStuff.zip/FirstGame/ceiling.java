import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ceiling here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ceiling extends Actor
{
    /**
     * Act - do whatever the ceiling wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public ceiling(int x, int y)
    {
        GreenfootImage ceilingImg = new GreenfootImage("red.png");
        ceilingImg.scale(x,y);
        setImage(ceilingImg);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
