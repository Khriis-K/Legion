
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Boss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Boss extends Actor
{
    /**
     * Act - do whatever the Boss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int count = 0;
    int sheildCount = 0;
    int worldWidth;
    int worldHeight;
    
    public Boss()
    {
        GreenfootImage packer = new GreenfootImage("packer.jpg");
        packer.scale(packer.getWidth()/2,packer.getHeight()/2);
        setImage(packer);
    }
    public void act() 
    {
        if(sheildCount == 0)
        {
           worldWidth = getWorld().getWidth();
           worldHeight = getWorld().getHeight();
           sheild();
           sheildCount = 1;
           //acornBounce();
           sideAttack();
        }
        //airstrike();
        
        
    }    
    public void sideAttack()
    {
        int distribute = worldHeight/10;
        for(int i = 1; i<10; i++)
        {
            submitSide subSide = new submitSide(true);
            getWorld().addObject(subSide,worldWidth,distribute*i);
            submitSide subSide2 = new submitSide(false);
            getWorld().addObject(subSide2,0,distribute*i);
        }
    }
    public void acornBounce()
    {
        acorn anAcorn = new acorn();
        getWorld().addObject(anAcorn,100,100);
        anAcorn.whenAddedToWorld();
    }
    public void airstrike()
    {
        count++;
        if(count>20)
        {
            count = 0;
            submit sub = new submit((int)(Math.random()*worldWidth),100);
            getWorld().addObject(sub,0,50);
            sub.addedToWorld();
        }
    }
    public void sheild()
    {
        Sheild sheild = new Sheild(getX(), getY());
        getWorld().addObject(sheild,getX(),0);
        
    }
}
