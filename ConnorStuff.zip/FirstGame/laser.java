import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class laser extends Actor
{
    /**
     * Act - do whatever the laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int count = 0;
    int startX;
    int startY;
    int endX;
    int endY;
    public laser(int rot, int mainX, int mainY)
    {
        GreenfootImage laserImg = new GreenfootImage("money.png");
        laserImg.scale(laserImg.getWidth()/10,laserImg.getHeight()/10);
        laserImg.rotate(rot-90);
        setImage(laserImg);
        endX = mainX;
        endY = mainY;
        
    }
    public void onceInWorld()
    {
        startX = getX();
        startY = getY();
    }
    public void act() 
    {
        setLocation(getX()+(endX-startX)/60,getY()+(endY-startY)/60);
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        }
    }    
}
