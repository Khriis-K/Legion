import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Tile1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelA extends World
{

    /**
     * Constructor for objects of class Tile1.
     * 
     */
    public LevelA()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1159,852, 1);
        setBackground("LevelA.jpeg");
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Main main = new Main();
        addObject(main,384,582);

        platform platform = new platform(600, 10);
        addObject(platform,684,626);
        platform.setLocation(450,698);

        wallLeft wallLeft = new wallLeft(10, 250);
        addObject(wallLeft,254,564);
        wallLeft.setLocation(250,567);

        wallLeft wallLeft2 = new wallLeft(10, 200);
        addObject(wallLeft2,1058,651);
        wallLeft2.setLocation(760,813);

        ceiling ceiling = new ceiling(500, 10);
        addObject(ceiling,899,565);
        ceiling.setLocation(470,457);

        wallLeft wallLeft4 = new wallLeft(10, 100);
        addObject(wallLeft4,906,573);
        wallLeft4.setLocation(725,404);

        ceiling ceiling2 = new ceiling(150, 10);
        addObject(ceiling2,661,600);
        ceiling2.setLocation(789,363);

        wallLeft wallLeft5 = new wallLeft(10, 300);
        addObject(wallLeft5,947,706);
        wallLeft5.setLocation(856,216);

        wallRight wallRight = new wallRight(10, 900);
        addObject(wallRight,911,621);
        wallRight.setLocation(1123,404);

        HP hP = new HP(140);
        addObject(hP,116,161);

        HpBar hpBar = new HpBar();
        addObject(hpBar,636,286);

        hpBar.setLocation(100,50);
        hP.setLocation(110,49);
        
    }
}
