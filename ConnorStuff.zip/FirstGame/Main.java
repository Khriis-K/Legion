import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Main here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Main extends Actor
{
    /**
     * Act - do whatever the Main wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int yAccel = 0;
    int fallClock = 0;
    int walkCount = 0;
    int upCount = 0;
    int downCount = 3;
    int shootCount = 0;
    boolean facingRight = true;

    boolean shooting = false;
    GreenfootImage[] walkCycleRight = new GreenfootImage[9];
    GreenfootImage[] walkCycleLeft = new GreenfootImage[9];
    GreenfootImage[] jumpCycleRight = new GreenfootImage[7];
    GreenfootImage[] jumpCycleLeft = new GreenfootImage[7];
    GreenfootImage[] shootCycleRight = new GreenfootImage[2];
    GreenfootImage[] shootCycleLeft = new GreenfootImage[2];
    public Main()
    {
        GreenfootImage image = getImage();
        image.scale(image.getWidth()/2, image.getHeight()/2);
        setImage(image);
        
        for(int i = 0; i<9; i++)
        {
            walkCycleRight[i] = new GreenfootImage("tile00" + i + ".png");
            walkCycleRight[i].scale(walkCycleRight[i].getWidth()/2,walkCycleRight[i].getHeight()/2);
            walkCycleLeft[i] = new GreenfootImage("tile00" + i + ".png");
            walkCycleLeft[i].mirrorHorizontally();
            walkCycleLeft[i].scale(walkCycleLeft[i].getWidth()/2,walkCycleLeft[i].getHeight()/2); 
        }
        for(int i = 0; i<6; i++)
        {
            jumpCycleRight[i] = new GreenfootImage("jump00" + i + ".png");
            jumpCycleRight[i].scale(jumpCycleRight[i].getWidth()/2,jumpCycleRight[i].getHeight()/2);
            jumpCycleLeft[i] = new GreenfootImage("jump00" + i + ".png");
            jumpCycleLeft[i].mirrorHorizontally();
            jumpCycleLeft[i].scale(jumpCycleLeft[i].getWidth()/2,jumpCycleLeft[i].getHeight()/2);
        }
        for(int i = 0; i<2; i++)
        {
            shootCycleRight[i] = new GreenfootImage("shoot" + i + ".png");
            shootCycleRight[i].scale(shootCycleRight[i].getWidth()/2,shootCycleRight[i].getHeight()/2);
            shootCycleLeft[i] = new GreenfootImage("shoot" + i + ".png");
            shootCycleLeft[i].mirrorHorizontally();
            shootCycleLeft[i].scale(shootCycleLeft[i].getWidth()/2,shootCycleLeft[i].getHeight()/2);
        }
    }
    public void act() 
    {
        move(); //movement, animations, and gravity
        shoot(); //shoot
        level(); //transitions and detections for moving thru levels
    }    
    public void level()
    {
        try
        {
            World world = (LevelA) getWorld();
            if(isAtEdge())
            {
                Greenfoot.setWorld(new LevelB(1, ((HP) getWorld().getObjects(HP.class).get(0)).getCurrentHP()));
            }
        }catch(ClassCastException x) {}
        try
        {
            World world = (LevelB) getWorld();
            if(getX()<10)
            {
                Greenfoot.setWorld(new LevelC(1, ((HP) getWorld().getObjects(HP.class).get(0)).getCurrentHP()));
            }
        }catch(ClassCastException x) {}
    }
    public boolean isGrounded()
    {
        if(isTouching(platform.class))
        {
            return true;
        }
        return false;
    }
    public void shoot()
    {
        if(Greenfoot.isKeyDown("space") && !shooting)
        {
            shooting = true;
        }
        if(shooting)
        {
            if(facingRight)
            {
                setImage(shootCycleRight[shootCount/15]);
            }
            else
            {
                setImage(shootCycleLeft[shootCount/15]);
            }
            shootCount++;
        }
        if(shootCount == 15)
        {
            Bullet bullet = new Bullet(facingRight);
            if(facingRight)
            {
                getWorld().addObject(bullet,getX()+30,getY()-20);
            }
            else
            {
                getWorld().addObject(bullet,getX()-30,getY()-20);
            }
        }
        if(shootCount>29)
        {
            shooting = false;
            shootCount = 0;
        }
    }
    public void move()
    {
        int x = getX();
        if(Greenfoot.isKeyDown("a") && !isTouching(wallLeft.class))
        {
            facingRight = false;
            x-=6;
            if(isGrounded())
            {
                setImage(walkCycleLeft[walkCount/2]);
                walkCount++;
                if(walkCount>17)
                {
                    walkCount = 0;
                }
            }
        }
        else if(isTouching(wallLeft.class))
        {
            facingRight = false;
            if(isGrounded())
            {
                setImage(walkCycleLeft[walkCount/2]);
                walkCount++;
                if(walkCount>17)
                {
                    walkCount = 0;
                }
            }
        }
        if(Greenfoot.isKeyDown("d") && !isTouching(wallRight.class))
        {
            facingRight = true;
            x+=6;
            if(isGrounded())
            {
                setImage(walkCycleRight[walkCount/2]);
                walkCount++;
                if(walkCount>17)
                {
                    walkCount = 0;
                }
            }
        }
        else if(isTouching(wallRight.class))
        {
            facingRight = true;
            if(isGrounded())
            {
                setImage(walkCycleRight[walkCount/2]);
                walkCount++;
                if(walkCount>17)
                {
                    walkCount = 0;
                }
            }
        }

        if(Greenfoot.isKeyDown("w") && isGrounded())
        {
            yAccel += 20;
  
        }
        if(!isGrounded())
        {
            if(yAccel <=0 && facingRight)
            {
                setImage(jumpCycleRight[downCount/6]);
                downCount++;
                if(downCount>30)
                {
                    downCount = 30;
                }
            }
            if(yAccel > 0 && facingRight)
            {
                setImage(jumpCycleRight[upCount/6]);
                upCount++;
                if(upCount>15)
                {
                    upCount = 15;
                }
            }
            if(yAccel <=0 && !facingRight)
            {
                setImage(jumpCycleLeft[downCount/6]);
                downCount++;
                if(downCount>30)
                {
                    downCount = 30;
                }
            }
            if(yAccel > 0 && !facingRight)
            {
                setImage(jumpCycleLeft[upCount/6]);
                upCount++;
                if(upCount>15)
                {
                    upCount = 15;
                }
            }
        }
        if(isGrounded())
        {
            upCount = 0;
            downCount = 16;
        }
        if(!Greenfoot.isKeyDown("d") && !Greenfoot.isKeyDown("a") &&  isGrounded())
        {
            if(facingRight)
            {
                setImage(walkCycleRight[0]);
            }
            else
            {
                setImage(walkCycleLeft[0]);
            }
        }
        setLocation(x,getY()-yAccel);
        fallClock++;
        if(fallClock>1)
        {
            fallClock = 0;
        }
        if(isGrounded())
        {
            yAccel = 0;
            
        }
        else if(fallClock==0)
        {
            yAccel -= 1;
        }
        
        if(isTouching(ceiling.class))
        {
            yAccel = 0;
            setLocation(x,getY()+1);
        }
    }
}
