import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelB here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelB extends World
{

    /**
     * Constructor for objects of class LevelB.
     * 
     */
    int CurrentHP;
    public LevelB(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(655, 672, 1);
        setBackground("LevelB.jpeg");
        if(entrance == 1)
        {
            Main main = new Main();
            addObject(main,200,0);

        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    public void prepare()
    {
        HP hP = new HP(CurrentHP);
        addObject(hP,138,67);
        HpBar hpBar = new HpBar();
        addObject(hpBar,200,150);
        hpBar.setLocation(90,30);
        hP.setLocation(100,29);
        platform platform = new platform(200, 10);
        addObject(platform,467,443);
        platform.setLocation(127,580);
        platform platform2 = new platform(75, 10);
        addObject(platform2,263,471);
        platform2.setLocation(269,518);
        platform platform3 = new platform(75, 10);
        addObject(platform3,397,501);
        platform3.setLocation(333,455);
        platform platform4 = new platform(200, 10);
        addObject(platform4,240,422);
        platform4.setLocation(482,384);
        removeObject(platform4);
        platform platform5 = new platform(400, 20);
        addObject(platform5,451,439);
        platform5.setLocation(554,391);
        wallRight wallRight = new wallRight(10, 50);
        addObject(wallRight,458,466);
        wallRight.setLocation(354,427);
        wallRight wallRight2 = new wallRight(10, 50);
        addObject(wallRight2,365,541);
        wallRight2.setLocation(290,489);
        wallRight wallRight3 = new wallRight(10, 40);
        addObject(wallRight3,233,602);
        wallRight3.setLocation(227,546);
        wallLeft wallLeft = new wallLeft(10, 50);
        addObject(wallLeft,28,543);
        wallLeft.setLocation(22,573);
        platform platform6 = new platform(25, 10);
        addObject(platform6,109,431);
        platform6.setLocation(3,549);
        wallRight wallRight4 = new wallRight(10, 400);
        addObject(wallRight4,80,216);
        wallRight4.setLocation(188,374);
        removeObject(wallRight4);
        wallRight wallRight6 = new wallRight(10, 200);
        addObject(wallRight6,335,269);
        wallRight6.setLocation(389,151);
        wallRight6.setLocation(389,151);
        wallLeft wallLeft2 = new wallLeft(10, 400);
        addObject(wallLeft2,265,321);
        wallLeft2.setLocation(22,202);
        ceiling ceiling = new ceiling(250, 10);
        addObject(ceiling,488,486);
        ceiling.setLocation(526,250);
        ceiling ceiling2 = new ceiling(25, 10);
        addObject(ceiling2,98,417);
        ceiling2.setLocation(5,405);

    }
}
