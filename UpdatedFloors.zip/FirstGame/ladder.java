import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ladder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ladder extends Actor
{
    /**
     * Act - do whatever the ladder wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public ladder()
    {
        GreenfootImage newLadder = new GreenfootImage("ladder.png");
        newLadder.scale(newLadder.getWidth()/4,newLadder.getHeight()/4);
        setImage(newLadder);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
