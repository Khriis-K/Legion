import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelC here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelC extends World
{

    /**
     * Constructor for objects of class LevelC.
     * 
     */
    int CurrentHP;
    public LevelC(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(766, 829, 1);
        setBackground("LevelC.jpeg");
        if(entrance == 1)
        {
            Main main = new Main();
            addObject(main,750,640);

        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    public void prepare()
    {
        HP hP = new HP(CurrentHP);
        addObject(hP,495,542);
        HpBar hpBar = new HpBar();
        addObject(hpBar,446,259);
        hpBar.setLocation(91,32);
        hP.setLocation(101,31);

        platform platform8 = new platform(250, 10);
        addObject(platform8,113,629);
        platform8.setLocation(643,708);
        wallLeft wallLeft = new wallLeft(10, 20);
        addObject(wallLeft,410,719);
        wallLeft.setLocation(536,692);

        platform platform9 = new platform(400, 10);
        addObject(platform9,372,397);
        platform9.setLocation(332,676);

        wallLeft wallLeft8 = new wallLeft(10, 100);
        addObject(wallLeft8,93,640);
        wallLeft8.setLocation(153,635);
        platform platform3 = new platform(100, 10);
        addObject(platform3,89,622);
        platform3.setLocation(100,579);
        wallLeft wallLeft3 = new wallLeft(10, 200);
        addObject(wallLeft3,51,418);
        wallLeft3.setLocation(56,475);
        ceiling ceiling = new ceiling(100, 10);
        addObject(ceiling,110,390);
        ceiling.setLocation(95,375);
        wallLeft wallLeft4 = new wallLeft(10, 50);
        addObject(wallLeft4,145,340);
        wallLeft4.setLocation(153,345);
        ceiling ceiling2 = new ceiling(400, 10);
        addObject(ceiling2,326,318);
        ceiling2.setLocation(300,312);
        ceiling2.setLocation(300,312);
        wallLeft wallLeft5 = new wallLeft(10, 50);
        addObject(wallLeft5,501,285);
        wallLeft5.setLocation(505,284);
        platform platform4 = new platform(350, 10);
        addObject(platform4,219,279);
        platform4.setLocation(324,257);
        wallLeft wallLeft6 = new wallLeft(10, 200);
        addObject(wallLeft6,148,180);
        wallLeft6.setLocation(152,163);
        wallLeft6.setLocation(153,161);
        ceiling ceiling3 = new ceiling(300, 10);
        addObject(ceiling3,520,285);
        ceiling3.setLocation(307,55);
        wallRight wallRight = new wallRight(10, 40);
        addObject(wallRight,488,147);
        wallRight.setLocation(459,73);
        ceiling ceiling4 = new ceiling(300, 10);
        addObject(ceiling4,471,203);
        ceiling4.setLocation(616,88);

        wallRight wallRight3 = new wallRight(10, 400);
        addObject(wallRight3,600,279);
        wallRight3.setLocation(709,285);
        platform platform5 = new platform(200, 10);
        addObject(platform5,543,405);

        platform platform6 = new platform(200, 10);
        addObject(platform6,565,491);

        platform6.setLocation(495,451);

        platform platform10 = new platform(120, 10);
        addObject(platform10,441,500);
        platform10.setLocation(331,486);
        wallRight wallRight6 = new wallRight(10, 75);
        addObject(wallRight6,490,464);
        wallRight6.setLocation(581,432);
        wallRight wallRight4 = new wallRight(10, 75);
        addObject(wallRight4,519,470);
        wallRight4.setLocation(388,499);

        platform5.setLocation(685,390);

        wallRight wallRight9 = new wallRight(10, 80);
        addObject(wallRight9,222,590);
        wallRight9.setLocation(260,532);

        ceiling ceiling6 = new ceiling(500, 10);
        addObject(ceiling6,397,545);
        ceiling6.setLocation(521,568);

        removeObject(wallLeft3);
        wallLeft wallLeft7 = new wallLeft(10, 300);
        addObject(wallLeft7,388,418);
        wallLeft7.setLocation(53,493);
        wallLeft7.setLocation(56,502);
    }
}
