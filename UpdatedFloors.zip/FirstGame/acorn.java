import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class acorn here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class acorn extends Actor
{
    /**
     * Act - do whatever the acorn wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int rot;
    int worldHeight;
    int worldWidth;
    int speedX = 5;
    int speedY = 5;
    int curveballFactor = 1;
    int count = 0;
    public acorn()
    {
        GreenfootImage acornImg = new GreenfootImage("acorn.png");
        acornImg.scale(acornImg.getWidth()/3,acornImg.getHeight()/3);
        setImage(acornImg);
        
    }
    public void whenAddedToWorld()
    {
        worldHeight = getWorld().getHeight();
        worldWidth = getWorld().getWidth();
    }
    public void act() 
    {
        if(getX()>worldWidth-50 || getX()<50)
        {
            speedX = -speedX;
            
        }
        if(getY()>worldHeight-50 || getY()<50)
        {
            speedY = -speedY;
            
        }
        if(count == 5)
        {
            speedY += curveballFactor;
            count = 0;
        }
        count++;
        setLocation(getX()+speedX,getY()+speedY);
    }    
}
