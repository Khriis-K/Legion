import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sheild here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sheild extends Actor
{
    /**
     * Act - do whatever the Sheild wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int bossX;
    int bossY;
    int stage = 0;
    int clickCount = 0;
    int clickMax = 30;
    GreenfootImage[] sheildArray = new GreenfootImage[4];
    public Sheild(int x, int y)
    {
        for(int i=0; i<4; i++)
        {
            GreenfootImage sheildImg = new GreenfootImage("sheild" + i + ".png");
            sheildImg.scale(sheildImg.getWidth()/3,sheildImg.getHeight()/3);
            sheildArray[i] = sheildImg;
        }
        setImage(sheildArray[0]);
        bossX = x;
        bossY = y;
    }
    public void act() 
    {
        if(stage == 0 && getY() < bossY)
        {
            setLocation(getX(),getY()+10);
        }
        else if(stage == 0)
        {
            stage = 1;
        }
        if(stage == 1 && clickCount < clickMax)
        {
            if(Greenfoot.mouseClicked(this))
            {
                clickCount++;
            }
            if(clickCount == clickMax/3)
            {
                setImage(sheildArray[1]);
            }
            if(clickCount == (clickMax/3)*2)
            {
                setImage(sheildArray[2]);
            }
            if(clickCount == clickMax-1)
            {
                setImage(sheildArray[3]);
            }
        }
        else if(stage == 1)
        {
            if(!isAtEdge())
            {
                setLocation(getX(),getY()-10);
            }
            else
            {
                getWorld().removeObject(this);
            }
        }    
    }
}
