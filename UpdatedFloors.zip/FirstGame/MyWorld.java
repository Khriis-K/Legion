import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Main main = new Main();
        addObject(main,605,369);
        Boss boss = new Boss();
        addObject(boss,123,305);
        boss.setLocation(91,459);
        HP hP = new HP(140); //CHANGE
        addObject(hP,236,154);
        hP.setLocation(110,44);
        HpBar hpBar = new HpBar();
        addObject(hpBar,411,178);
        hpBar.setLocation(100,45);
        

    }
}
