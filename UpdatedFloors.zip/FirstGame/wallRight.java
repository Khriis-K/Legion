import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class wallRight here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class wallRight extends Actor
{
    /**
     * Act - do whatever the wallRight wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public wallRight(int x, int y)
    {
        GreenfootImage wallImg = new GreenfootImage("green.png");
        wallImg.scale(x,y);
        setImage(wallImg);
    }
    public wallRight(int y)
    {
        GreenfootImage wallImg = new GreenfootImage("green.png");
        wallImg.scale(10,y);
        setImage(wallImg);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
