import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class wallLeft here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class wallLeft extends Actor
{
    /**
     * Act - do whatever the wallLeft wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public wallLeft(int x, int y)
    {
        GreenfootImage wallImg = new GreenfootImage("blue.png");
        wallImg.scale(x,y);
        setImage(wallImg);
    }
    public wallLeft(int y)
    {
        GreenfootImage wallImg = new GreenfootImage("blue.png");
        wallImg.scale(10,y);
        setImage(wallImg);
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
