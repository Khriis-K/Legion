import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class submit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class submit extends Actor
{
    /**
     * Act - do whatever the submit wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    GreenfootImage[] laserCycle = new GreenfootImage[6];
    int animCounter = 0;
    int animCounter2 = 18;
    int stage = 0;
    int submitX;
    int submitY;
    int fireTimer = 0;
    double targetRot;
    int mainX;
    int mainY;
    
    public submit(int x, int y)
    {
        for(int i = 1; i<7; i++)
        {
            laserCycle[i-1] = new GreenfootImage("submit" + i + ".png");
        }
        submitX = x;
        submitY = y;
        this.setImage(laserCycle[0]);
        //this.getImage().rotate((int)(Math.random()*360));
        
    }
    public void addedToWorld()
    {
        mainX = ((Actor)getWorld().getObjects(Actor.class).get(0)).getX();
        mainY = ((Actor)getWorld().getObjects(Actor.class).get(0)).getY();
        if(mainX>submitX)
        {
            targetRot = 90-Math.toDegrees(Math.atan(((double)(mainX-submitX))/(submitY-mainY)));
        }
        if(mainX<submitX)
        {
            targetRot = 90+Math.toDegrees(Math.atan(((double)(submitX-mainX))/(submitY-mainY)));
        }
        for(GreenfootImage i: laserCycle)
        {
            i.rotate((2*(90-(int)targetRot))+(int)targetRot);
        }
    }
    
    public void act() 
    {
        move();
        
        
        //getImage().rotate((int)(Math.random()*360));
        //getImage().rotate((int)targetRot);
        
    }
    public void move()
    {
        
        if(getX()<submitX && stage == 0)
        {
            setLocation(getX()+10,getY());
        }
        else if(stage == 0)
        {
            stage = 1;
        }
        if(animCounter<18 && stage == 1)
        {
                setImage(laserCycle[animCounter/3]);
                animCounter++;
        }
        else if(stage == 1)
        {
            stage = 2;
            laser beam = new laser((2*(90-(int)targetRot))+(int)targetRot, mainX, mainY);
            getWorld().addObject(beam,getX(),getY());
            beam.onceInWorld();
        }
        if(fireTimer < 25 && stage == 2)
        {
            fireTimer++;
        }
        else if (stage == 2)
        {
            stage = 3;
            
        }
        if(stage == 3 && animCounter2>=0 )
        {
            
            animCounter2--;
            setImage(laserCycle[animCounter2/3]);
            
        }
        else if(stage ==3)
        {
            stage = 4;
        }
        if(!isAtEdge() && stage == 4)
        {
            setLocation(getX()+10,getY());
        }
        else if(isAtEdge() && stage == 4)
        {
            getWorld().removeObject(this);
        }
        
     
    }
    
    
    
}
