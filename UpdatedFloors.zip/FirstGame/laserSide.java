import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class laserSide here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class laserSide extends Actor
{
    /**
     * Act - do whatever the laserSide wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    boolean fromRight;
    public laserSide(boolean isFromRight)
    {
        GreenfootImage laserImg = new GreenfootImage("money.png");
        laserImg.scale(laserImg.getWidth()/20,laserImg.getHeight()/20);
        setImage(laserImg);
        fromRight = isFromRight;
        
    }
    public void act() 
    {
        if(fromRight)
        {
            setLocation(getX()-5,getY());
        }
        else
        {
            setLocation(getX()+5    ,getY());
        }
        if(isAtEdge())
        {
            getWorld().removeObject(this);
        }
    }    
}
