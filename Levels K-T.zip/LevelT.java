import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelT here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelT extends World
{

    /**
     * Constructor for objects of class LevelT.
     * 
     */
    int CurrentHP;
    public LevelT(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 574, 1); 
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level T.jpeg");
        levelBackground.scale(800, 574);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main, 729 , 260 );
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    private void prepare()
    {
        platform platform = new platform( 110 );
        addObject(platform, 701 , 322 );
        
        platform platform2 = new platform( 600 );
        addObject(platform2, 346 , 469 );
        
        ceiling ceiling = new ceiling( 110 );
        addObject(ceiling, 700 , 166 );
        
        ceiling ceiling2 = new ceiling( 600);
        addObject(ceiling2, 346, 24);
        
        wallLeft wallLeft = new wallLeft( 450 );
        addObject(wallLeft, 39 , 245 );
        
        wallRight wallRight = new wallRight( 110 );
        addObject(wallRight, 651 , 95 );
        
        wallRight wallRight2 = new wallRight( 140 );
        addObject(wallRight2, 765 , 244 );

        wallRight wallRight3 = new wallRight( 120 );
        addObject(wallRight3, 649 , 394 );
    }
}
