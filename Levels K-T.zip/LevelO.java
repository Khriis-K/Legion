import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelO here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelO extends World
{

    /**
     * Constructor for objects of class LevelO.
     * 
     */
    int CurrentHP;
    public LevelO(int entrance, int CurrentHP)
    {    
        super(1013, 568, 1);
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level O.jpeg");
        levelBackground.scale(1013,568);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            //scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main, 70 , 440 );
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    private void prepare()
    {
        platform platform = new platform( 100 );
        addObject(platform, 67, 507 );
        
        platform platform2 = new platform( 300 );
        addObject(platform2, 287, 467 );
        
        platform platform3 = new platform( 60 );
        addObject(platform3, 487 , 347 );
        
        platform platform4 = new platform( 130 );
        addObject(platform4, 120 , 184 );
        
        platform platform5 = new platform( 270 );
        addObject(platform5, 668 , 467 );
        
        ceiling ceiling = new ceiling( 165 );
        addObject(ceiling, 100 , 256 );
        
        ceiling ceiling2 = new ceiling( 950 );
        addObject(ceiling2, 526 , 14 );
        
        wallLeft wallLeft = new wallLeft( 150 );
        addObject(wallLeft, 36 , 101 );
        
        wallLeft wallLeft2 = new wallLeft( 40 );
        addObject(wallLeft2, 200 , 218 );
        
        wallLeft wallLeft3 = new wallLeft( 100 );
        addObject(wallLeft3, 522 , 406 );
        
        wallLeft wallLeft4 = new wallLeft( 80 );
        addObject(wallLeft4, 805 , 519 );
        
        wallRight wallRight = new wallRight( 100 );
        addObject(wallRight, 454 , 406 );
        
        wallRight wallRight2 = new wallRight( 530 );
        addObject(wallRight2, 978 , 296 );
        
        wallRight wallRight3 = new wallRight( 10 );
        addObject(wallRight3, 129 , 486 );
        
        
    }
}
