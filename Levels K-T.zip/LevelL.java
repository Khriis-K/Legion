import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelL here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelL extends World
{

    /**
     * Constructor for objects of class LevelL.
     * 
     */
    int CurrentHP;
    public LevelL(int entrance, int CurrentHP)
    {    
        super(1015, 557, 1);
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level L.jpeg");
        levelBackground.scale(1015,557);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main,901,78);
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        HP hP = new HP(CurrentHP);
        addObject(hP,495,542);
        HpBar hpBar = new HpBar();
        addObject(hpBar,446,259);
        hpBar.setLocation(91,32);
        hP.setLocation(101,31);
        
        wallRight wallRight = new wallRight(500);
        addObject(wallRight,1001,304);

        platform platform = new platform(270);
        addObject(platform,865,528);

        wallLeft wallLeft = new wallLeft(130);
        addObject(wallLeft,722,488);

        platform platform2 = new platform(93);
        addObject(platform2,670,412);

        wallLeft wallLeft2 = new wallLeft(120);
        addObject(wallLeft2,608,362);

        platform platform3 = new platform(80);
        addObject(platform3,556,297);

        wallRight wallRight2 = new wallRight(220);
        addObject(wallRight2,506,429);

        platform platform4 = new platform(120);
        addObject(platform4,441,527);

        wallLeft wallLeft3 = new wallLeft(105);
        addObject(wallLeft3,376,477);

        platform platform5 = new platform(320);
        addObject(platform5,210,413);

        wallLeft wallLeft4 = new wallLeft(200);
        addObject(wallLeft4,32,312);

        ceiling ceiling = new ceiling(375);
        addObject(ceiling,195,206);

        wallLeft wallLeft5 = new wallLeft(50);
        addObject(wallLeft5,382,188);

        ceiling ceiling2 = new ceiling(10);
        addObject(ceiling2,396,170);

        wallLeft wallLeft6 = new wallLeft(60);
        addObject(wallLeft6,415,147);

        platform platform6 = new platform(80);
        addObject(platform6,366,106);

        wallLeft wallLeft7 = new wallLeft(140);
        addObject(wallLeft7,302,70);
        
        ceiling ceiling3 = new ceiling( 470 );
        addObject(ceiling3, 765 , 4 );
    }
}
