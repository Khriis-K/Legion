import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelQ here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelQ extends World
{

    /**
     * Constructor for objects of class LevelQ.
     * 
     */
    int CurrentHP;
    public LevelQ(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1013, 568, 1); 
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level Q.jpeg");
        levelBackground.scale(1013, 568);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main, 75 , 515 );
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    private void prepare()
    {
        platform platform = new platform( 730 );
        addObject(platform, 380 , 555 );
        
        platform platform2 = new platform( 480 );
        addObject(platform2, 270 , 438 );
        
        platform platform3 = new platform( 410 );
        addObject(platform3, 763 , 320 );
        
        platform platform4 = new platform( 460 );
        addObject(platform4, 270 , 202 );
        
        platform platform5 = new platform( 410 );
        addObject(platform5, 758 , 85 );
        
        platform platform6 = new platform( 50 );
        addObject(platform6, 814 , 37 );
        
        ceiling ceiling = new ceiling( 480 );
        addObject(ceiling, 278 , 471 );
        
        ceiling ceiling2 = new ceiling( 410 );
        addObject(ceiling2, 763 , 355 );
        
        ceiling ceiling3 = new ceiling( 460 );
        addObject(ceiling3, 279 , 236 );
        
        ceiling ceiling4 = new ceiling( 410 );
        addObject(ceiling4, 756 , 117 );
        
        ceiling ceiling5 = new ceiling( 700 );
        addObject(ceiling5, 381 , 3 );
        
        wallLeft wallLeft = new wallLeft( 40 );
        addObject(wallLeft, 527 , 457 );

        wallLeft wallLeft2 = new wallLeft( 200 );
        addObject(wallLeft2, 18 , 330 );
        
        wallLeft wallLeft3 = new wallLeft( 40 );
        addObject(wallLeft3, 526 , 221 );
        
        wallLeft wallLeft4 = new wallLeft( 180 );
        addObject(wallLeft4, 18 , 101 );
        
        wallLeft wallLeft5 = new wallLeft( 15 );
        addObject(wallLeft5, 838 , 62);
        
        wallRight wallRight = new wallRight( 40 );
        addObject(wallRight, 538 , 338 );
        
        wallRight wallRight2 = new wallRight( 40 );
        addObject(wallRight2, 538 , 102);
        
        wallRight wallRight3 = new wallRight( 200 );
        addObject(wallRight3, 989 , 464 );
        
        wallRight wallRight4 = new wallRight( 200 );
        addObject(wallRight4, 989 , 218);
        
        wallRight wallRight5 = new wallRight( 15 );
        addObject(wallRight5, 791 , 62 );
        
        wallRight wallRight6 = new wallRight( 80 );
        addObject(wallRight6, 989 , 32 );
    }
}
