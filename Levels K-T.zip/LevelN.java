import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelN here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelN extends World
{

    /**
     * Constructor for objects of class LevelN.
     * 
     */
    int CurrentHP;
    public LevelN(int entrance, int CurrentHP)
    {    
        super(730, 567, 1);
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/level N.jpeg");
        levelBackground.scale(730,567);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            //scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main,94,167);
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        platform platform = new platform(200);
        addObject(platform,152,235);

        platform platform2 = new platform(375);
        addObject(platform2,447,449);

        platform platform3 = new platform(110);
        addObject(platform3, 622, 193);

        platform platform4 = new platform(75);
        addObject(platform4, 688, 535);

        ceiling ceiling = new ceiling(700);
        addObject(ceiling, 367, 9);

        ceiling ceiling2 = new ceiling(160);
        addObject(ceiling2, 645, 265);
        
        wallLeft wallLeft = new wallLeft(200);
        addObject(wallLeft, 37, 124);
        
        wallLeft wallLeft2 = new wallLeft( 180 );
        addObject(wallLeft2, 251 , 343 );
        
        wallLeft wallLeft3 = new wallLeft( 50 );
        addObject(wallLeft3, 637 , 491 );
        
        wallRight wallRight = new wallRight( 30 );
        addObject(wallRight, 562 , 230 );
        
        wallRight wallRight2 = new wallRight( 150 );
        addObject(wallRight2, 692 , 104 );
    }
}
