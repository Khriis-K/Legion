import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelK here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelK extends World
{

    /**
     * Constructor for objects of class LevelK.
     * 
     */
    int CurrentHP;
    public LevelK(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(709, 570, 1);
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level K.jpeg");
        levelBackground.scale(709,570);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 0.9);
            int newHeight = (int) (scaledMain.getHeight() * 0.9);
            scaledMain.scale(newWidth, newHeight);

            main.setImage(scaledMain);
            addObject(main,580,145);
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    public void prepare()
    {
        HP hP = new HP(CurrentHP);
        addObject(hP,495,542);
        HpBar hpBar = new HpBar();
        addObject(hpBar,446,259);
        hpBar.setLocation(91,32);
        hP.setLocation(101,31);

        platform platform = new platform(215, 10);
        addObject(platform,570,206);

        platform platform2 = new platform(430, 10);
        addObject(platform2,247,303);

        wallRight wallRight = new wallRight(10, 180);
        addObject(wallRight,682,125);

        wallRight wallRight2 = new wallRight(10, 100);
        addObject(wallRight2,468,264);

        wallRight wallRight3 = new wallRight(265);
        addObject(wallRight3,36,436);

        ceiling ceiling1 = new ceiling(440, 10);
        addObject(ceiling1,463,41);
        
        ceiling ceiling2 = new ceiling(300);
        addObject(ceiling2,111,164);

        wallLeft wallLeft = new wallLeft(10, 140);
        addObject(wallLeft,241,98);
    }
}
