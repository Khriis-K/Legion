import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelS here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelS extends World
{

    /**
     * Constructor for objects of class LevelS.
     * 
     */
    int CurrentHP;
    public LevelS(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1019, 176, 1);
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level S.jpeg");
        levelBackground.scale(1019, 176);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main, 979 , 73 );
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    private void prepare()
    {
        platform platform = new platform( 975 );
        addObject(platform, 526 , 116 );
        
        ceiling ceiling = new ceiling( 975 );
        addObject(ceiling, 526 , 17 );

        wallLeft wallLeft = new wallLeft( 90 );
        addObject(wallLeft, 28 , 72 );
    }
}
