import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelP here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelP extends World
{

    /**
     * Constructor for objects of class LevelP.
     * 
     */
    int CurrentHP;
    public LevelP(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(763, 694, 1); 
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level P.jpeg");
        levelBackground.scale(763, 694);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main, 613 , 63 );
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    private void prepare()
    {
        platform platform = new platform( 105 );
        addObject(platform, 611 , 130 );
        
        platform platform2 = new platform( 105 );
        addObject(platform2, 479 , 514 );
        
        platform platform3 = new platform( 200 );
        addObject(platform3, 654 , 641 );
        
        ceiling ceiling = new ceiling( 95 );
        addObject(ceiling, 611 , 243 );
        
        ceiling ceiling2 = new ceiling( 65 );
        addObject(ceiling2, 718 , 438 );

        wallLeft wallLeft = new wallLeft( 500 );
        addObject(wallLeft, 410 , 251 );
        
        wallLeft wallLeft2 = new wallLeft( 100 );
        addObject(wallLeft2, 538 , 579 );
        
        wallRight wallRight = new wallRight( 120 );
        addObject(wallRight, 680 , 61 );
        
        wallRight wallRight2 = new wallRight( 90 );
        addObject(wallRight2, 550 , 188 );
        
        wallRight wallRight3 = new wallRight( 170 );
        addObject(wallRight3, 678 , 341 );
    }
}
