import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelR here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelR extends World
{

    /**
     * Constructor for objects of class LevelR.
     * 
     */
    int CurrentHP;
    public LevelR(int entrance, int CurrentHP)
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1024, 162, 1); 
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level R.jpeg");
        levelBackground.scale(1024, 162);
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main, 797 , 65 );
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }
    
    private void prepare()
    {
        platform platform = new platform( 810 );
        addObject(platform, 407 , 107 );
        
        ceiling ceiling = new ceiling( 1000 );
        addObject(ceiling, 498 , 15 );
        
        wallRight wallRight = new wallRight( 140 );
        addObject(wallRight, 1008 , 89 );
    }
}
