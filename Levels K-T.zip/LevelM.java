import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LevelL here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LevelM extends World
{

    /**
     * Constructor for objects of class LevelL.
     * 
     */
    int CurrentHP;
    public LevelM(int entrance, int CurrentHP)
    {    
        super(822, 727, 1);
        GreenfootImage levelBackground = new GreenfootImage("Levels K-T/Photoshop/Level M.jpeg");
        setBackground(levelBackground);
        if(entrance == 1)
        {
            Main main = new Main();
            GreenfootImage scaledMain = main.getImage();
            
            int newWidth = (int) (scaledMain.getWidth() * 1.0);
            int newHeight = (int) (scaledMain.getHeight() * 1.0);
            scaledMain.scale(newWidth, newHeight);
            scaledMain.mirrorHorizontally();

            main.setImage(scaledMain);
            
            addObject(main,311,649);
        }
        this.CurrentHP = CurrentHP;
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        HP hP = new HP(CurrentHP);
        addObject(hP,495,542);
        HpBar hpBar = new HpBar();
        addObject(hpBar,446,259);
        hpBar.setLocation(91,32);
        hP.setLocation(101,31);

        platform platform = new platform(80);
        addObject(platform,306,711);

        platform platform2 = new platform(10);
        addObject(platform2,245,648);

        platform platform3 = new platform(45);
        addObject(platform3,193,583);

        platform platform4 = new platform(110);
        addObject(platform4,101,616);

        platform platform5 = new platform(400);
        addObject(platform5,595,487);

        platform platform6 = new platform(200);
        addObject(platform6,146,327);

        ceiling ceiling = new ceiling(400);
        addObject(ceiling,603,538);

        ceiling ceiling2 = new ceiling(200);
        addObject(ceiling2,144,380);

        ceiling ceiling3 = new ceiling(10);
        addObject(ceiling3,46,125);

        ceiling ceiling4 = new ceiling(10);
        addObject(ceiling4,76,92);

        ceiling ceiling5 = new ceiling(250);
        addObject(ceiling5,229,59);

        ceiling ceiling6 = new ceiling(25);
        addObject(ceiling6,370,187);

        ceiling ceiling7 = new ceiling(30);
        addObject(ceiling7,419,289);

        ceiling ceiling8 = new ceiling(215);
        addObject(ceiling8,674,315);

        wallLeft wallLeft = new wallLeft(30);
        addObject(wallLeft,253,683);

        wallLeft wallLeft2 = new wallLeft(30);
        addObject(wallLeft2,220,613);

        wallLeft wallLeft3 = new wallLeft(250);
        addObject(wallLeft3,28,498);

        wallLeft wallLeft4 = new wallLeft(30);
        addObject(wallLeft4,253,356);

        wallLeft wallLeft5 = new wallLeft(250);
        addObject(wallLeft5,28,222);

        wallLeft wallLeft6 = new wallLeft(25);
        addObject(wallLeft6,60,120);

        wallLeft wallLeft7 = new wallLeft(10);
        addObject(wallLeft7,93,82);

        wallLeft wallLeft8 = new wallLeft(300);
        addObject(wallLeft8,445,139);

        wallLeft wallLeft9 = new wallLeft(10);
        addObject(wallLeft9,349,725);
        
        wallRight wallRight = new wallRight(30);
        addObject(wallRight,391,520);

        wallRight wallRight2 = new wallRight(100);
        addObject(wallRight2,360,121);

        wallRight wallRight3 = new wallRight(100);
        addObject(wallRight3,393,239);

        wallRight wallRight4 = new wallRight(300);
        addObject(wallRight4,552,157);

        wallRight wallRight5 = new wallRight(130);
        addObject(wallRight5,808,402);

        wallRight wallRight6 = new wallRight(10);
        addObject(wallRight6,170,599);

        
    }
}
